"""缺陷检测器模块（ONNX Runtime 推理 — 容器部署版，检测模型）。

模型：YOLOv11n 检测模型在训练端由 ultralytics 导出的 ONNX
（models/best.onnx，输入 640x640，输出 [1, 4+类别数, 8400]）。

使用方式：置物平台每次只有 1 个物料，因此流程为
  检测 → NMS → 取置信度最高的目标 → 类别映射为 PLC 组号：
  孔洞 hole(1) / 缺角 notch(2) / 划痕 scratch(3) / 污渍 stain(4)

容器内仅需 onnxruntime，无需 torch / ultralytics（镜像更轻、启动更快）。
类别名优先读取 ONNX 元数据（ultralytics 导出时写入），读不到则回退到
config.yaml 的 classes.names（顺序必须与训练 dataset.yaml 一致）。
"""
from __future__ import annotations

import ast
import logging
from dataclasses import dataclass
from pathlib import Path

import numpy as np

try:
    from .config import AppConfig, VisionError
except ImportError:  # 脚本模式回退
    from config import AppConfig, VisionError


def default_model_path() -> Path:
    """模型路径：src/ 同级的 models/best.onnx。"""
    return Path(__file__).resolve().parent.parent / "models" / "best.onnx"


@dataclass
class ClsResult:
    """单次推理结果（置信度最高的目标）。"""
    cls_name: str             # 'none' 表示画面中没有可信目标
    conf: float
    topk: list                # 该目标的类别得分 top3 [(name, conf), ...]
    box: tuple = ()           # 目标框 (x1, y1, x2, y2)，原图坐标；无目标为 ()


class DefectClassifier:
    """ONNX 检测模型：每帧取置信度最高的物料目标输出类别。"""

    # 检测内部阈值（NMS 前过滤），最终是否上报仍由 cfg.conf 决定
    DET_CONF = 0.25
    NMS_IOU = 0.45

    def __init__(self, cfg: AppConfig, logger: logging.Logger):
        self.cfg = cfg
        self.logger = logger
        model_path = Path(cfg.model_path) if cfg.model_path else default_model_path()
        if not model_path.exists():
            raise VisionError(f"模型文件不存在: {model_path}")
        try:
            import onnxruntime as ort
        except ImportError as e:
            raise VisionError(
                "onnxruntime 未安装，容器镜像构建时请加入 requirements") from e

        # 推理后端：默认 CPU（EPC1502 无独显）
        providers = ["CPUExecutionProvider"]
        if str(cfg.device).startswith("cuda"):
            providers.insert(0, "CUDAExecutionProvider")
        self._session = ort.InferenceSession(str(model_path), providers=providers)
        inp = self._session.get_inputs()[0]
        self._input_name = inp.name
        # 输入尺寸以模型为准（导出时固定，如 640x640），不依赖配置
        self._imgsz = int(inp.shape[2]) if len(inp.shape) == 4 else cfg.imgsz
        self.logger.info("加载模型: %s (providers=%s, 输入=%dx%d)",
                         model_path, providers, self._imgsz, self._imgsz)

        # 类别名：优先读 ONNX 元数据（ultralytics 导出时写入 names）
        self._names = self._load_names(cfg.class_names)
        self.logger.info("类别表: %s", self._names)

        if cfg.warmup:
            self.warmup()

    def _load_names(self, fallback: list) -> list:
        """从 ONNX 元数据读取类别名，失败则回退到配置。"""
        try:
            meta = self._session.get_modelmeta().custom_metadata_map
            raw = meta.get("names")
            if raw:
                names = ast.literal_eval(raw)          # {0: 'hole', ...}
                return [names[i] for i in sorted(names)]
        except Exception as e:  # noqa: BLE001
            self.logger.warning("读取 ONNX 类别元数据失败: %s，回退到配置", e)
        return list(fallback)

    def warmup(self) -> None:
        """预热推理（避免首帧延迟拉高比赛计时）。"""
        dummy = np.zeros((1, 3, self._imgsz, self._imgsz), dtype=np.float32)
        self._session.run(None, {self._input_name: dummy})
        self.logger.info("模型预热完成")

    # ---------------- 图像预处理：letterbox（保持长宽比，与训练一致） ----------------
    def _letterbox(self, image: np.ndarray):
        """BGR 图 → 640x640 模型输入；返回 (blob, scale, pad_w, pad_h)。"""
        import cv2
        h, w = image.shape[:2]
        s = self._imgsz
        scale = min(s / w, s / h)
        nw, nh = int(round(w * scale)), int(round(h * scale))
        img = cv2.resize(image, (nw, nh))
        canvas = np.full((s, s, 3), 114, dtype=np.uint8)
        pad_w, pad_h = (s - nw) // 2, (s - nh) // 2
        canvas[pad_h:pad_h + nh, pad_w:pad_w + nw] = img
        blob = cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB)
        blob = blob.astype(np.float32) / 255.0
        return np.expand_dims(blob.transpose(2, 0, 1), axis=0), scale, pad_w, pad_h

    # ---------------- 推理 ----------------
    @staticmethod
    def create_run_options():
        """为单次推理创建可独立终止的 ONNX RunOptions。"""
        import onnxruntime as ort
        return ort.RunOptions()

    @staticmethod
    def cancel(run_options) -> None:
        """终止与 run_options 关联的本次 ONNX 推理。"""
        if run_options is not None:
            run_options.terminate = True

    def detect(self, image: np.ndarray, run_options=None) -> ClsResult:
        """检测 → NMS → 返回置信度最高的物料目标。"""
        import cv2
        blob, scale, pad_w, pad_h = self._letterbox(image)
        pred = self._session.run(
            None, {self._input_name: blob}, run_options
        )[0][0].T
        # pred: [8400, 4+nc]，前 4 列为 cx,cy,w,h（模型输入坐标系），其后为各类别得分
        boxes_cxcywh = pred[:, :4]
        cls_scores = pred[:, 4:]
        cls_ids = np.argmax(cls_scores, axis=1)
        confs = cls_scores[np.arange(len(cls_scores)), cls_ids]

        mask = confs >= self.DET_CONF
        if not np.any(mask):
            return ClsResult(cls_name="none", conf=0.0, topk=[])

        boxes = boxes_cxcywh[mask]
        scores = confs[mask]
        ids = cls_ids[mask]
        # NMS（cv2 需要左上角 xywh 格式）
        boxes_xywh = boxes.copy()
        boxes_xywh[:, 0] = boxes[:, 0] - boxes[:, 2] / 2
        boxes_xywh[:, 1] = boxes[:, 1] - boxes[:, 3] / 2
        keep = cv2.dnn.NMSBoxes(boxes_xywh.tolist(), scores.tolist(),
                                self.DET_CONF, self.NMS_IOU)
        if len(keep) == 0:
            return ClsResult(cls_name="none", conf=0.0, topk=[])
        keep = np.array(keep).flatten()

        # 单物料场景：取置信度最高的目标
        best = keep[int(np.argmax(scores[keep]))]
        cls_id = int(ids[best])
        conf = float(scores[best])

        # 目标框换算回原图坐标（供调试图标注）
        cx, cy, w, h = boxes[best]
        x1 = (cx - w / 2 - pad_w) / scale
        y1 = (cy - h / 2 - pad_h) / scale
        x2 = (cx + w / 2 - pad_w) / scale
        y2 = (cy + h / 2 - pad_h) / scale

        topk_idx = np.argsort(cls_scores[mask][best])[::-1][:3]
        topk = [(self._names[int(i)], round(float(cls_scores[mask][best][i]), 4))
                for i in topk_idx]
        return ClsResult(cls_name=self._names[cls_id], conf=conf,
                         topk=topk, box=(x1, y1, x2, y2))

    def to_plc_group_id(self, cls_name: str) -> int:
        """类别名 → PLC 组号（1=hole, 2=notch, 3=scratch, 4=stain）。"""
        if cls_name not in self.cfg.plc_group_id:
            self.logger.warning("未知类别 %s，回退上报组号 1", cls_name)
            return 1
        return int(self.cfg.plc_group_id[cls_name])
