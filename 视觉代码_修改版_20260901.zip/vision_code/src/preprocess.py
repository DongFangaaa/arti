"""图像预处理模块（v3.0 — grayscale + gaussian + CLAHE）。

简化流水线：
  1. 灰度化（彩色图 → 单通道灰度图）
  2. 高斯去噪（GaussianBlur）
  3. CLAHE 自适应直方图均衡化

依赖：opencv-python >= 4.5
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

import cv2
import numpy as np


@dataclass
class PreprocessConfig:
    enable: bool = True

    # 高斯去噪
    denoise: str = "gaussian"       # gaussian | none
    denoise_ksize: int = 5          # 高斯核大小（奇数），0 表示自动 (3)

    # CLAHE
    clahe: bool = True
    clahe_clip: float = 2.0         # clipLimit，建议 2.0~4.0
    clahe_tile: int = 8             # tileGridSize


class Preprocessor:
    def __init__(self, cfg: PreprocessConfig, logger: logging.Logger | None = None):
        self.cfg = cfg
        self.logger = logger or logging.getLogger("vision.preprocess")
        if cfg.denoise not in ("gaussian", "none"):
            self.logger.warning(
                "unknown denoise=%s, fallback to 'gaussian'", cfg.denoise)
            cfg.denoise = "gaussian"
        if cfg.clahe:
            self._clahe = cv2.createCLAHE(
                clipLimit=max(0.1, cfg.clahe_clip),
                tileGridSize=(cfg.clahe_tile, cfg.clahe_tile),
            )
        else:
            self._clahe = None

    def run(self, image: np.ndarray) -> np.ndarray:
        """执行完整预处理流水线：灰度 → 高斯去噪 → CLAHE。"""
        if not self.cfg.enable:
            return image

        # 1) 灰度化
        img = self._to_gray(image)

        # 2) 高斯去噪
        img = self._denoise(img)

        # 3) CLAHE
        if self._clahe is not None:
            img = self._clahe.apply(img)

        return img

    # ------------------------------------------------------------------
    # 子函数
    # ------------------------------------------------------------------
    def _to_gray(self, image: np.ndarray) -> np.ndarray:
        if image.ndim == 2:
            return image
        if image.ndim == 3 and image.shape[2] == 3:
            return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        if image.ndim == 3 and image.shape[2] == 4:
            return cv2.cvtColor(image, cv2.COLOR_BGRA2GRAY)
        raise ValueError(f"unsupported image shape: {image.shape}")

    def _denoise(self, image: np.ndarray) -> np.ndarray:
        if self.cfg.denoise != "gaussian":
            return image
        k = self.cfg.denoise_ksize
        if k <= 0:
            k = 3
        if k % 2 == 0:
            k += 1
        return cv2.GaussianBlur(image, (k, k), 0)

    def crop_roi(self, image: np.ndarray,
                 x: int, y: int, w: int, h: int) -> np.ndarray:
        """裁剪 ROI；用于去除传送带背景。"""
        H, W = image.shape[:2]
        x = max(0, min(x, W - 1))
        y = max(0, min(y, H - 1))
        w = max(1, min(w, W - x))
        h = max(1, min(h, H - y))
        return image[y:y + h, x:x + w]


# ============================================================================
# 向后兼容：旧 API
# ============================================================================
# 旧代码若直接 import method5_combined / denoise / sharpen，提供 shim：
def method5_combined(img: np.ndarray, gamma: float = 0.8,
                     clip_limit: float = 2.0, tile_size: int = 8) -> np.ndarray:
    """兼容 model/scripts/enhance_contrast.py 的 method5_combined 接口（近似）。"""
    pre = Preprocessor(PreprocessConfig(
        clahe=True, clahe_clip=clip_limit, clahe_tile=tile_size,
        denoise="none",
    ))
    gray = pre._to_gray(img)
    return pre._clahe.apply(gray) if pre._clahe is not None else gray


def denoise(img: np.ndarray, strength: int = 3) -> np.ndarray:
    """兼容 model/scripts/enhance_contrast.py 的 denoise 接口。"""
    pre = Preprocessor(PreprocessConfig(denoise="gaussian", denoise_ksize=5))
    return pre._denoise(pre._to_gray(img))


def sharpen(img: np.ndarray, amount: float = 1.5, sigma: float = 1.5) -> np.ndarray:
    """兼容 model/scripts/enhance_contrast.py 的 sharpen 接口（v3.0 已移除锐化，直接返回）。"""
    pre = Preprocessor(PreprocessConfig(denoise="none"))
    return pre._to_gray(img)
