# PLC 程序目录

> 📂 **此目录用于存放 PLC 程序**——比赛最后集成阶段由 PLC 工程师填入。
>
> 当前**仅含 `.gitkeep`**，实际 ST 文件由 PLC 工程师在 PLCnext Engineer 工程里编写后导出。

## 应包含的文件（比赛最终版）

```
src/plc/
├── README.md                  # 本文件
├── main_program.st            # 主状态机（ST_INIT / ST_WAIT_VISION / ST_CALC_TARGET / ST_UPDATE / ST_READY）
├── fb_shelf_manager.st        # 货架管理功能块（缺陷类型→库位映射）
└── modbus_var_definition.md   # Modbus 寄存器定义说明（5 个视觉交互变量）
```

## PLC 工程师需要做的

1. 在 **PLCnext Engineer** 里新建工程
2. 定义 5 个 INT 变量并映射到 Modbus Holding Register：
   - `xVisionTrigger`（HR100，PLC→Vision，0/1）
   - `xDefectClass`（HR110，Vision→PLC，0=hole, 1=notch, 2=scratch, 3=stain, -1=未识别）
   - `fConfidence`（HR111，Vision→PLC，0~1000）
   - `xResultValid`（HR112，Vision→PLC，0/1）
   - `iResultSeq`（HR113，Vision→PLC，序列号）
3. 启用 Modbus TCP Server（端口 502），从站号 unit_id=1
4. 编写 ST 代码（main_program.st 状态机）
5. 编译下载到 EPC 1502
6. 把 PLC IP 填到 `vision/config.yaml` 的 `plc.modbus_tcp.host`

## 关于命名

- PLCnext 与我们的 `.st` 文件**都是 IEC 61131-3 Structured Text 标准**，可互拷
- PLCnext 工程的 `.st` 依赖 PLCnext 元数据，**不能直接放进此目录**——需要 PLC 工程师手动把核心逻辑块复制出来

## 比赛前自检

- [ ] `main_program.st` 编译通过（PLCnext Engineer）
- [ ] Modbus TCP Server 启动成功（端口 502）
- [ ] 5 个变量可在 Modbus Poll 中读写
- [ ] PLC IP 已填到 `vision/config.yaml`
- [ ] PLC 程序能在 EPC 1502 上独立运行（视觉容器没起时不应崩溃）

---

*目录版本 v2.4 — 2026-08-20（协议从 OPC UA 改为 Modbus TCP）*
