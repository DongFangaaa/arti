"""PLC 通讯模块入口。

按 vision/config.yaml 中的 plc.protocol 字段选择实现：
    - "modbus_tcp" → ModbusTcpComm（v2.4 起唯一支持的协议，赛题要求 TCP）

新增实现只需在 _REGISTRY 注册即可，main.py 无需改动。
modbus_udp 已在 v2.4 弃用，相关类保留以兼容旧 import，但不再被注册。
"""
from __future__ import annotations

import logging

from .base import PlcComm, PlcResult
from .modbus_comm import ModbusTcpComm, ModbusUdpComm  # noqa: F401  ModbusUdpComm 仅供兼容

# 实现注册表（key = 协议名小写，value = 类）
_REGISTRY: dict[str, type[PlcComm]] = {}


def build_comm(cfg: dict, logger: logging.Logger | None = None) -> PlcComm:
    """按 cfg["protocol"] 选择具体实现。

    cfg 形如：
        plc:
          protocol: "modbus_tcp"
          modbus_tcp:
            host: 127.0.0.1
            port: 502
            unit_id: 1
            registers: {trigger: 100, defect_class: 110, ...}
    """
    if not _REGISTRY:
        _load_builtins()

    protocol = cfg.get("protocol", "modbus_tcp").lower()
    impl_cfg = cfg.get(protocol, cfg.get("modbus", {}))

    cls = _REGISTRY.get(protocol)
    if cls is None:
        raise ValueError(
            f"Unknown PLC protocol: {protocol}. "
            f"Available: {list(_REGISTRY)}")
    return cls(impl_cfg, logger)


def _load_builtins() -> None:
    """加载内置实现（延迟加载避免不必要的 import）。"""
    from .modbus_comm import ModbusTcpComm
    _REGISTRY["modbus_tcp"] = ModbusTcpComm


__all__ = ["PlcComm", "PlcResult", "build_comm"]